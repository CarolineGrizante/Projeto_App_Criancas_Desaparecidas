/*
  PROJETO: Crianças Desaparecidas - Protótipo Mobile
  Este arquivo controla o comportamento da aplicação:
  - troca de telas pelo seletor e pela navegação inferior;
  - abertura de detalhes dos casos;
  - formulários simulados;
  - alertas e mensagens Toast;
  - alternância entre tema claro e escuro;
  - gráfico didático dos sensores.
  Os dados usados aqui são fictícios e servem somente para demonstração.
*/
let currentScreen = "home",
  previousScreen = "home",
  theme = "dark",
  sensorTimer = null;
const cases = [
  {
    id: 1,
    name: "Pedro Santos",
    age: "8 anos",
    city: "Araras, SP",
    neighborhood: "Centro (Praça Barão)",
    time: "Hoje às 16:30",
    bo: "BO-2026-984123",
    clothes: "Camisa azul listrada, bermuda jeans e tênis preto",
    description:
      "Visto por último próximo à Praça Barão de Araras. Possui uma pequena cicatriz no braço esquerdo.",
    initials: "PS",
  },
  {
    id: 2,
    name: "Maria Lima",
    age: "5 anos",
    city: "Leme, SP",
    neighborhood: "Bairro Alto",
    time: "Ontem às 14:00",
    bo: "BO-2026-771209",
    clothes: "Vestido rosa com estampas de flores, sandálias amarelas",
    description: "Desapareceu nas proximidades da escola primária municipal.",
    initials: "ML",
  },
  {
    id: 3,
    name: "Lucas Oliveira",
    age: "10 anos",
    city: "Rio Claro, SP",
    neighborhood: "Jardim Claret",
    time: "20/10/2026 às 11:20",
    bo: "BO-2026-554311",
    clothes: "Camiseta vermelha, calça moletom cinza e boné preto",
    description: "Estava andando de bicicleta perto do parque da cidade.",
    initials: "LO",
  },
];
const titles = {
  home: "♧　Início & Emergência",
  login: "↪　Autenticação",
  register: "♙　Novo Cadastro",
  form: "▤　Registrar Desaparecimento",
  cases: "⌕　Casos em Busca",
  profile: "▣　Perfil & B.O.s",
  sensors: "⌁　Lab de Sensores PDM",
};
const area = document.querySelector("#screen-area"),
  phone = document.querySelector("#phone");
const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (m) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        m
      ],
  );
function showToast(message, type = "info") {
  const el = document.createElement("div");
  el.className = `toast ${type === "danger" ? "danger" : ""}`;
  el.textContent = message;
  document.querySelector("#toast-container").appendChild(el);
  setTimeout(() => el.remove(), 3200);
}
function card(c, small = false) {
  return `<article class="case-mini case-card" data-id="${c.id}"><div class="case-avatar">${c.initials}</div><div class="case-info"><strong>${esc(c.name)} <span style="font-weight:400">(${c.age})</span></strong><small>${esc(c.city)} · ${esc(c.neighborhood)}</small><small>${esc(c.time)}</small></div><span class="ok">B.O. OK</span></article>`;
}
function renderHome() {
  area.innerHTML = `<div class="screen-content"><div class="emergency"><div class="emergency-head"><span>⚠　ALERTA DE EMERGÊNCIA</span><span class="emergency-tag">LIGUE 190</span></div><p>Desaparecimento recente? As primeiras horas são decisivas. Entre em contato com os canais policiais oficiais.</p><div class="two-actions"><a class="phone-button" href="tel:190" data-call="190">☎ Polícia 190</a><a class="phone-button secondary" href="tel:181" data-call="181">♢ Pistas 181</a></div></div><div class="quick-grid"><button class="quick" data-screen="form"><span class="quick-icon">▤</span><strong>Registrar Caso</strong><small>Com B.O. obrigatório</small></button><button class="quick" data-screen="cases"><span class="quick-icon">⌕</span><strong>Buscar Crianças</strong><small>Filtrar região Araras</small></button><button class="quick" data-screen="sensors"><span class="quick-icon">⌁</span><strong>Laboratório</strong><small>Dados dos sensores</small></button><button class="quick" data-screen="profile"><span class="quick-icon">♙</span><strong>Meu perfil</strong><small>Conta verificada</small></button></div><div class="section-line"><h3>▰　Alertas ativos</h3><span>Araras & Região</span></div>${cases.map(card).join("")}</div>`;
}
function renderLogin() {
  area.innerHTML = `<div class="screen-content"><div class="center"><div class="auth-logo">♧</div><h2 class="phone-heading">Acessar o sistema</h2><p class="muted">Crianças Desaparecidas · Apoio e Busca</p></div><div class="card"><label class="input-label">E-mail ou CPF<input class="phone-input" value="roberto.silva@fho.edu.br" /></label><label class="input-label">Senha de acesso<input class="phone-input" type="password" value="12345678" /></label><label class="muted"><input type="checkbox" checked /> Lembrar deste dispositivo</label><button class="primary-button" id="login-submit">Entrar com segurança　→</button><button class="outline-button" data-screen="register">Criar nova conta</button></div><p class="muted center">Ao continuar, você concorda com os Termos de Uso e a Política de Privacidade.</p></div>`;
  document.querySelector("#login-submit").onclick = () => {
    showToast("Login realizado com sucesso.", "success");
    loadScreen("home");
  };
}
function renderRegister() {
  area.innerHTML = `<div class="screen-content"><div><span class="overline">CADASTRO DE RESPONSÁVEL</span><h2 class="phone-heading">Crie seu vínculo com a rede</h2><p class="muted">A identificação ajuda a manter a plataforma segura.</p></div><div class="card"><label class="input-label">Nome completo<input class="phone-input" placeholder="Ex.: Roberto da Silva" /></label><label class="input-label">CPF<input class="phone-input" placeholder="000.000.000-00" /></label><label class="input-label">Telefone<input class="phone-input" placeholder="(00) 00000-0000" /></label><label class="input-label">Vínculo<select class="phone-select"><option>Familiar</option><option>Cidadão colaborador</option><option>Representante institucional</option></select></label><label class="muted"><input type="checkbox" /> Aceito os Termos e a Política de Privacidade.</label><button class="primary-button" id="register-submit">Criar conta　→</button></div></div>`;
  document.querySelector("#register-submit").onclick = () => {
    showToast("Conta criada no modo demonstração.", "success");
    loadScreen("home");
  };
}
function renderForm() {
  area.innerHTML = `<div class="screen-content"><div><span class="overline">NOVO ALERTA · PASSO 1 DE 2</span><h2 class="phone-heading">Registrar desaparecimento</h2><p class="muted">Preencha os dados com atenção.</p></div><div class="card"><div class="form-title"><b>01</b><div><strong>Dados da criança</strong><span> identificação básica</span></div></div><label class="input-label">Nome completo<input id="child-name" class="phone-input" placeholder="Ex.: João Pedro Oliveira" /></label><label class="input-label">Idade<input class="phone-input" type="number" placeholder="Anos" /></label><label class="input-label">Último local visto<input class="phone-input" placeholder="Cidade, bairro ou ponto de referência" /></label><label class="input-label">Características e roupas<textarea class="phone-textarea" rows="3" placeholder="Descreva características importantes..."></textarea></label></div><div class="card"><div class="form-title"><b>02</b><div><strong>Validação legal</strong><span> B.O. obrigatório</span></div></div><label class="input-label">Número do Boletim de Ocorrência<input id="bo-number" class="phone-input" placeholder="BO-2026-000000" /></label><label class="input-label">Delegacia responsável<input class="phone-input" placeholder="Ex.: 3ª D.P. — Centro" /></label><p class="info-note">✓ O número do B.O. confirma que o caso foi comunicado às autoridades e evita trotes.</p></div><div class="card"><div class="form-title"><b>03</b><div><strong>Localização e mídia</strong><span> recursos nativos</span></div></div><button class="outline-button" id="gps-button">⌖　Marcar último local pelo GPS</button><button class="outline-button" id="camera-button">▧　Adicionar foto da galeria</button></div><label class="muted"><input type="checkbox" id="image-consent" /> Autorizo o uso da imagem para fins de busca.</label><button class="primary-button" id="submit-case">Confirmar e enviar alerta　→</button></div>`;
  document.querySelector("#gps-button").onclick = () => {
    showToast("Localização simulada: Praça Barão, Araras.", "success");
  };
  document.querySelector("#camera-button").onclick = () =>
    showToast("Seletor de foto aberto no modo demonstração.");
  document.querySelector("#submit-case").onclick = () => {
    showToast("Alerta registrado. B.O. validado.", "success");
    setTimeout(() => loadScreen("cases"), 700);
  };
}
function renderCases() {
  area.innerHTML = `<div class="screen-content"><div><span class="overline">BUSCA REGIONAL</span><h2 class="phone-heading">Crianças em busca</h2><p class="muted">Registros ativos em Araras e região.</p></div><div class="search-box"><input id="case-search" class="phone-input" placeholder="Nome, cidade ou B.O..." /><button class="filter">☷</button></div><div id="case-results">${cases.map(card).join("")}</div><p class="info-note">⚠ Ao reconhecer uma criança, não se aproxime sozinho. Envie uma pista pelo 181 ou ligue 190.</p></div>`;
  document.querySelector("#case-search").oninput = (e) => {
    const q = e.target.value.toLowerCase();
    document.querySelector("#case-results").innerHTML =
      cases
        .filter((c) =>
          [c.name, c.city, c.bo, c.neighborhood].some((v) =>
            v.toLowerCase().includes(q),
          ),
        )
        .map(card)
        .join("") || '<p class="muted center">Nenhum caso encontrado.</p>';
    bindCaseCards();
  };
  bindCaseCards();
}
function bindCaseCards() {
  document
    .querySelectorAll(".case-card")
    .forEach((el) => (el.onclick = () => openCase(Number(el.dataset.id))));
}
function openCase(id) {
  const c = cases.find((x) => x.id === id);
  document.querySelector("#modal-content").innerHTML =
    `<span class="ok">✓ B.O. VALIDADO PELA POLÍCIA</span><h2 class="phone-heading">${esc(c.name)}, ${c.age}</h2><p class="muted">${esc(c.city)} · ${esc(c.neighborhood)}<br />Último registro: ${esc(c.time)}</p><div class="detail-block"><b>Características informadas</b><p>${esc(c.clothes)}</p><p>${esc(c.description)}</p></div><div class="detail-block"><b>Localização aproximada</b><p>⌖ ${esc(c.neighborhood)} · ${esc(c.city)}</p></div><button class="primary-button" data-call="181">Enviar uma pista　→</button><button class="outline-button" data-call="181">Ligar 181 · Disque-Denúncia</button>`;
  document.querySelector("#modal").classList.remove("hidden");
  document
    .querySelectorAll("#modal-content [data-call]")
    .forEach(
      (b) =>
        (b.onclick = () =>
          showToast("Canal 181 aberto para encaminhar a pista.", "danger")),
    );
}
function renderProfile() {
  area.innerHTML = `<div class="screen-content"><div class="profile-head"><div class="profile-avatar">RS</div><div><strong>Dr. Roberto Silva</strong><small>Responsável cadastrado · Araras, SP</small></div></div><div class="card"><div class="section-line"><h3>Dados da conta</h3><span>VERIFICADA ✓</span></div><div class="profile-row">E-mail<span>roberto.silva@fho.edu.br</span></div><div class="profile-row">Telefone<span>(19) 99999-0000</span></div><div class="profile-row">B.O.s cadastrados<span>01</span></div></div><div class="card"><div class="section-line"><h3>Segurança e permissões</h3></div><div class="profile-row">Localização GPS<span style="color:var(--green)">ATIVA</span></div><div class="profile-row">Câmera do dispositivo<span style="color:var(--green)">ATIVA</span></div><div class="profile-row">Notificações de alerta<span style="color:var(--green)">ATIVA</span></div></div><button class="outline-button" id="logout">Sair da conta</button></div>`;
  document.querySelector("#logout").onclick = () => {
    showToast("Sessão encerrada.");
    loadScreen("login");
  };
}
function renderSensors() {
  area.innerHTML = `<div class="screen-content"><div class="sensor-header"><div><span class="overline">HARDWARE DIDÁTICO</span><h2 class="phone-heading">Laboratório PDM</h2><p class="muted">Acelerômetro · Giroscópio · GPS</p></div><span class="live">● AO VIVO</span></div><div class="card"><div class="section-line"><h3>Movimento em tempo real</h3><span>m/s²</span></div><canvas id="sensor-canvas" class="sensor-chart" width="330" height="180"></canvas></div><div class="axes"><div class="axis"><b>EIXO X</b><strong id="axis-x">0.00</strong><small>m/s²</small></div><div class="axis"><b>EIXO Y</b><strong id="axis-y">0.00</strong><small>m/s²</small></div><div class="axis"><b>EIXO Z</b><strong id="axis-z">9.81</strong><small>m/s²</small></div></div><div class="card"><p class="info-note">⌁ O acelerômetro mede a variação de velocidade nos eixos X, Y e Z. Os valores desta tela são simulados para demonstrar a integração com o hardware nativo.</p><button class="outline-button" id="pause-sensors">Pausar leitura</button></div></div>`;
  startSensors();
}
function drawSensor() {
  const canvas = document.querySelector("#sensor-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d"),
    w = canvas.width,
    h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = "#ffffff14";
  for (let i = 1; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(0, (i * h) / 5);
    ctx.lineTo(w, (i * h) / 5);
    ctx.stroke();
  }
  const colors = ["#9e1c1c", "#5e9cda", "#49d39b"];
  colors.forEach((color, ci) => {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    for (let i = 0; i < 30; i++) {
      const x = (i * w) / 29,
        y =
          h / 2 +
          Math.sin(Date.now() / 650 + i * 0.45 + ci) * 22 +
          (Math.random() - 0.5) * 9 +
          (ci === 2 ? 28 : 0);
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    }
    ctx.stroke();
  });
}
function startSensors() {
  clearInterval(sensorTimer);
  sensorTimer = setInterval(() => {
    ["x", "y"].forEach(
      (k) =>
        document.querySelector(`#axis-${k}`) &&
        (document.querySelector(`#axis-${k}`).textContent = (
          Math.random() * 4 -
          2
        ).toFixed(2)),
    );
    document.querySelector("#axis-z") &&
      (document.querySelector("#axis-z").textContent = (
        9.81 +
        (Math.random() - 0.5) * 0.6
      ).toFixed(2));
    drawSensor();
  }, 650);
  drawSensor();
}
function loadScreen(screen) {
  clearInterval(sensorTimer);
  previousScreen = currentScreen;
  currentScreen = screen;
  document.querySelector("#screen-selector").value = screen;
  document.querySelector("#bar-title").innerHTML = titles[screen];
  document
    .querySelector("#back-button")
    .classList.toggle("hidden", screen === "home");
  document
    .querySelectorAll(".bottom-nav button")
    .forEach((b) => b.classList.toggle("active", b.dataset.screen === screen));
  (
    ({
      home: renderHome,
      login: renderLogin,
      register: renderRegister,
      form: renderForm,
      cases: renderCases,
      profile: renderProfile,
      sensors: renderSensors,
    })[screen] || renderHome
  )();
  area.scrollTop = 0;
}
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-screen]");
  if (b) loadScreen(b.dataset.screen);
  const call = e.target.closest("[data-call]");
  if (call && call.tagName !== "A")
    showToast(`Canal ${call.dataset.call} aberto.`, "danger");
});
document.querySelector("#screen-selector").onchange = (e) =>
  loadScreen(e.target.value);
document.querySelector("#theme-toggle").onclick = () => {
  theme = theme === "dark" ? "light" : "dark";
  phone.className = `phone theme-${theme}`;
  document.querySelector("#theme-toggle").textContent =
    theme === "dark" ? "☾" : "☀";
  showToast(`Tema ${theme === "dark" ? "escuro" : "claro"} ativado.`);
};
document.querySelector("#test-alert").onclick = () => {
  showToast(
    "🚨 ALERTA DE EMERGÊNCIA: novo caso registrado em Araras-SP!",
    "danger",
  );
  loadScreen("home");
};
document.querySelector("#back-button").onclick = () =>
  loadScreen(previousScreen);
document.querySelector("#profile-button").onclick = () => loadScreen("profile");
document.querySelector("#close-modal").onclick = () =>
  document.querySelector("#modal").classList.add("hidden");
setInterval(() => {
  document.querySelector("#phone-clock").textContent =
    new Date().toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });
}, 1000);
loadScreen("home");
