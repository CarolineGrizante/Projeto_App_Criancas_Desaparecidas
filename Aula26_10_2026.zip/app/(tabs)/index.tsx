import { Ionicons } from "@expo/vector-icons";
import { useMemo, useState, type ReactNode } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";

type Screen = "login" | "signup" | "verify" | "forgot" | "gov";
type NoticeType = "success" | "error" | "info";

type Notice = {
  type: NoticeType;
  message: string;
};

type FieldProps = {
  label: string;
  value: string;
  placeholder: string;
  onChangeText: (value: string) => void;
  icon: keyof typeof Ionicons.glyphMap;
  keyboardType?: "default" | "email-address" | "numeric";
  secureTextEntry?: boolean;
  onToggleSecure?: () => void;
  error?: string;
  autoCapitalize?: "none" | "sentences" | "words";
};

const COLORS = {
  background: "#0B0E0D",
  surface: "#141918",
  surfaceRaised: "#1A201E",
  border: "#29332F",
  text: "#F4F7F4",
  muted: "#8B9690",
  subtle: "#5D6962",
  lime: "#C8FF3D",
  limeDark: "#A7D52B",
  coral: "#FF8578",
  amber: "#F5C86A",
};

const DEMO_CODE = "246810";

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <View style={[styles.brand, compact && styles.brandCompact]}>
      <View style={styles.brandIcon}>
        <Ionicons name="shield-checkmark-outline" size={compact ? 20 : 23} color={COLORS.lime} />
      </View>
      <View>
        <Text style={[styles.wordmark, compact && styles.wordmarkCompact]}>guardião</Text>
        {!compact && <Text style={styles.brandCaption}>apoio com responsabilidade</Text>}
      </View>
    </View>
  );
}

function ProgressDots({ step }: { step: number }) {
  return (
    <View style={styles.progressRow} accessibilityLabel={`Etapa ${step} de 3`}>
      {[1, 2, 3].map((item) => (
        <View key={item} style={[styles.progressDot, item <= step && styles.progressDotActive]} />
      ))}
      <Text style={styles.progressLabel}>ETAPA {step} DE 3</Text>
    </View>
  );
}

function Field({
  label,
  value,
  placeholder,
  onChangeText,
  icon,
  keyboardType = "default",
  secureTextEntry = false,
  onToggleSecure,
  error,
  autoCapitalize = "none",
}: FieldProps) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={[styles.inputShell, error && styles.inputShellError]}>
        <Ionicons name={icon} size={18} color={error ? COLORS.coral : COLORS.muted} />
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={COLORS.subtle}
          keyboardType={keyboardType}
          secureTextEntry={secureTextEntry}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          selectionColor={COLORS.lime}
          style={styles.input}
        />
        {onToggleSecure && (
          <Pressable onPress={onToggleSecure} hitSlop={10} accessibilityLabel="Mostrar ou ocultar palavra-passe">
            <Ionicons name={secureTextEntry ? "eye-outline" : "eye-off-outline"} size={18} color={COLORS.muted} />
          </Pressable>
        )}
      </View>
      {error ? <Text style={styles.fieldError}>{error}</Text> : null}
    </View>
  );
}

function NoticeBanner({ notice }: { notice: Notice }) {
  const icon = notice.type === "success" ? "checkmark-circle-outline" : notice.type === "error" ? "alert-circle-outline" : "information-circle-outline";
  const color = notice.type === "success" ? COLORS.lime : notice.type === "error" ? COLORS.coral : COLORS.amber;
  return (
    <View style={[styles.notice, { borderColor: `${color}55`, backgroundColor: `${color}10` }]}>
      <Ionicons name={icon} size={18} color={color} />
      <Text style={[styles.noticeText, { color }]}>{notice.message}</Text>
    </View>
  );
}

function PrimaryButton({
  children,
  onPress,
  loading = false,
  disabled = false,
  icon,
}: {
  children: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [styles.primaryButton, (pressed || disabled) && styles.primaryButtonPressed]}
    >
      {loading ? <ActivityIndicator color={COLORS.background} /> : <Text style={styles.primaryButtonText}>{children}</Text>}
      {!loading && icon && <Ionicons name={icon} size={18} color={COLORS.background} />}
    </Pressable>
  );
}

function BackButton({ onPress, label = "Voltar" }: { onPress: () => void; label?: string }) {
  return (
    <Pressable onPress={onPress} style={styles.backButton} hitSlop={8}>
      <Ionicons name="arrow-back" size={18} color={COLORS.text} />
      <Text style={styles.backButtonText}>{label}</Text>
    </Pressable>
  );
}

function ScreenFrame({ children, onBack, backLabel }: { children: ReactNode; onBack?: () => void; backLabel?: string }) {
  const insets = useSafeAreaInsets();
  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "left", "right", "bottom"]}>
      <View style={[styles.page, { paddingTop: Math.max(insets.top * 0.18, 8) }]}>
        <View style={styles.topBar}>
          {onBack ? <BackButton onPress={onBack} label={backLabel} /> : <BrandMark compact />}
          <View style={styles.livePill}>
            <View style={styles.liveDot} />
            <Text style={styles.livePillText}>PROTÓTIPO</Text>
          </View>
        </View>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.content}>{children}</View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

function LoginScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [notice, setNotice] = useState<Notice | undefined>();
  const [loading, setLoading] = useState(false);
  const [identifierError, setIdentifierError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const handleLogin = () => {
    setIdentifierError("");
    setPasswordError("");
    setNotice(undefined);
    let valid = true;
    if (!identifier.trim()) {
      setIdentifierError("Informe o e-mail ou CPF para continuar.");
      valid = false;
    }
    if (!password.trim()) {
      setPasswordError("Informe a sua palavra-passe.");
      valid = false;
    }
    if (!valid) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setNotice({ type: "success", message: "Acesso demonstrativo realizado. Próximo passo: consultar alertas." });
    }, 700);
  };

  return (
    <ScreenFrame>
      <View style={styles.loginIntro}>
        <View style={styles.signalLine}>
          <View style={styles.signalLineFill} />
        </View>
        <Text style={styles.eyebrow}>ENTRAR COM SEGURANÇA</Text>
        <Text style={styles.title}>Informação certa, no momento certo.</Text>
        <Text style={styles.subtitle}>Entre para ajudar com responsabilidade e manter a sua comunidade protegida.</Text>
      </View>

      <View style={styles.formCard}>
        <Text style={styles.cardKicker}>ACESSO À SUA CONTA</Text>
        <Text style={styles.cardTitle}>Vamos começar</Text>
        <Text style={styles.cardDescription}>Use os seus dados para aceder ao protótipo do Guardião.</Text>

        <Field
          label="E-MAIL OU CPF"
          value={identifier}
          onChangeText={setIdentifier}
          placeholder="Digite o seu e-mail ou CPF"
          icon="person-outline"
          keyboardType="email-address"
          error={identifierError}
        />
        <Field
          label="PALAVRA-PASSE"
          value={password}
          onChangeText={setPassword}
          placeholder="Digite a sua palavra-passe"
          icon="lock-closed-outline"
          secureTextEntry={!showPassword}
          onToggleSecure={() => setShowPassword((value) => !value)}
          error={passwordError}
        />

        <Pressable onPress={() => onNavigate("forgot")} style={styles.forgotLink}>
          <Text style={styles.linkText}>Esqueci-me da palavra-passe</Text>
          <Ionicons name="arrow-up-right-box" size={15} color={COLORS.lime} />
        </Pressable>

        {notice && <NoticeBanner notice={notice} />}
        <PrimaryButton onPress={handleLogin} loading={loading} icon="arrow-forward">
          Entrar no protótipo
        </PrimaryButton>

        <View style={styles.dividerRow}>
          <View style={styles.divider} />
          <Text style={styles.dividerText}>OU</Text>
          <View style={styles.divider} />
        </View>

        <Pressable onPress={() => onNavigate("gov")} style={styles.govButton}>
          <View style={styles.govBadge}><Text style={styles.govBadgeText}>G</Text></View>
          <View style={styles.govCopy}>
            <Text style={styles.govTitle}>Entrar com Gov.br</Text>
            <Text style={styles.govSubtitle}>Opção didática, sem integração real</Text>
          </View>
          <Ionicons name="chevron-forward" size={17} color={COLORS.muted} />
        </Pressable>
      </View>

      <View style={styles.createRow}>
        <Text style={styles.mutedText}>Ainda não tem uma conta?</Text>
        <Pressable onPress={() => onNavigate("signup")}>
          <Text style={styles.linkText}>Criar conta</Text>
        </Pressable>
      </View>

      <View style={styles.privacyNote}>
        <Ionicons name="shield-checkmark-outline" size={15} color={COLORS.subtle} />
        <Text style={styles.privacyText}>Os seus dados são tratados com cuidado e respeito.</Text>
      </View>
    </ScreenFrame>
  );
}

function SignupScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSignup = () => {
    const nextErrors: Record<string, string> = {};
    if (!name.trim()) nextErrors.name = "Informe o seu nome.";
    if (!email.trim() || !email.includes("@")) nextErrors.email = "Digite um e-mail válido.";
    if (password.length < 6) nextErrors.password = "Use pelo menos 6 caracteres.";
    if (confirmPassword !== password) nextErrors.confirm = "As palavras-passe não coincidem.";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onNavigate("verify");
    }, 650);
  };

  return (
    <ScreenFrame onBack={() => onNavigate("login")}>
      <ProgressDots step={1} />
      <View style={styles.innerIntro}>
        <Text style={styles.eyebrow}>NOVO ACESSO</Text>
        <Text style={styles.title}>Crie o seu espaço seguro.</Text>
        <Text style={styles.subtitle}>Uma conta validada ajuda a manter a rede de apoio mais confiável.</Text>
      </View>

      <View style={styles.formCard}>
        <Field label="NOME COMPLETO" value={name} onChangeText={setName} placeholder="Como podemos chamar você?" icon="person-outline" autoCapitalize="words" error={errors.name} />
        <Field label="E-MAIL" value={email} onChangeText={setEmail} placeholder="voce@exemplo.com" icon="mail-outline" keyboardType="email-address" error={errors.email} />
        <Field label="PALAVRA-PASSE" value={password} onChangeText={setPassword} placeholder="Mínimo de 6 caracteres" icon="lock-closed-outline" secureTextEntry={!showPassword} onToggleSecure={() => setShowPassword((value) => !value)} error={errors.password} />
        <Field label="CONFIRME A PALAVRA-PASSE" value={confirmPassword} onChangeText={setConfirmPassword} placeholder="Repita a sua palavra-passe" icon="checkmark-circle-outline" secureTextEntry={!showConfirm} onToggleSecure={() => setShowConfirm((value) => !value)} error={errors.confirm} />
        <Text style={styles.helperText}>Ao continuar, você concorda em utilizar a plataforma com responsabilidade.</Text>
        <PrimaryButton onPress={handleSignup} loading={loading} icon="arrow-forward">
          Criar a minha conta
        </PrimaryButton>
      </View>
    </ScreenFrame>
  );
}

function VerifyScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [code, setCode] = useState("");
  const [notice, setNotice] = useState<Notice | undefined>();
  const [loading, setLoading] = useState(false);
  const isVerified = notice?.type === "success";

  const handleVerify = () => {
    if (code.trim().length !== 6) {
      setNotice({ type: "error", message: "Digite o código de 6 números recebido no seu e-mail." });
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setNotice(code === DEMO_CODE
        ? { type: "success", message: "Conta validada com sucesso. Pode entrar quando quiser." }
        : { type: "error", message: "Esse código não confere. Para a demonstração, use 246810." });
    }, 500);
  };

  return (
    <ScreenFrame onBack={() => onNavigate("signup")}>
      <ProgressDots step={2} />
      <View style={styles.innerIntro}>
        <View style={styles.verificationIcon}><Ionicons name={isVerified ? "checkmark" : "mail-open-outline"} size={30} color={COLORS.lime} /></View>
        <Text style={styles.eyebrow}>VALIDAR CONTA</Text>
        <Text style={styles.title}>{isVerified ? "Tudo certo por aqui." : "Só mais um cuidado."}</Text>
        <Text style={styles.subtitle}>{isVerified ? "A sua identidade foi confirmada neste protótipo." : "Digite o código de 6 números para confirmar que este e-mail é seu."}</Text>
      </View>

      <View style={styles.formCard}>
        {!isVerified && (
          <>
            <Text style={styles.cardKicker}>CÓDIGO DE DEMONSTRAÇÃO</Text>
            <TextInput
              value={code}
              onChangeText={(value) => setCode(value.replace(/[^0-9]/g, "").slice(0, 6))}
              placeholder="000000"
              placeholderTextColor={COLORS.subtle}
              keyboardType="numeric"
              maxLength={6}
              selectionColor={COLORS.lime}
              style={styles.codeInput}
              textContentType="oneTimeCode"
            />
            {notice && <NoticeBanner notice={notice} />}
            <PrimaryButton onPress={handleVerify} loading={loading} icon="checkmark">
              Validar a minha conta
            </PrimaryButton>
            <Pressable onPress={() => setNotice({ type: "info", message: "Novo código enviado (simulação local)." })} style={styles.centerLink}>
              <Text style={styles.linkText}>Reenviar código</Text>
            </Pressable>
          </>
        )}
        {isVerified && (
          <>
            <NoticeBanner notice={notice} />
            <PrimaryButton onPress={() => onNavigate("login")} icon="arrow-forward">
              Ir para o login
            </PrimaryButton>
          </>
        )}
      </View>
      <Text style={styles.demoHint}>Dica para a apresentação: use o código 246810.</Text>
    </ScreenFrame>
  );
}

function ForgotScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [identifier, setIdentifier] = useState("");
  const [notice, setNotice] = useState<Notice | undefined>();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const sent = notice?.type === "success";

  const handleRecover = () => {
    setError("");
    if (!identifier.trim()) {
      setError("Informe o e-mail ou CPF da sua conta.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setNotice({ type: "success", message: "Pedido registado no protótipo. Verifique o seu e-mail quando esta função estiver ligada." });
    }, 650);
  };

  return (
    <ScreenFrame onBack={() => onNavigate("login")}>
      <ProgressDots step={3} />
      <View style={styles.innerIntro}>
        <View style={styles.verificationIcon}><Ionicons name={sent ? "checkmark" : "key-outline"} size={29} color={COLORS.lime} /></View>
        <Text style={styles.eyebrow}>RECUPERAR ACESSO</Text>
        <Text style={styles.title}>{sent ? "Pedido recebido." : "Acontece com todo mundo."}</Text>
        <Text style={styles.subtitle}>{sent ? "Este é um retorno simulado para a sua apresentação." : "Informe um dado da sua conta e mostramos como será a recuperação."}</Text>
      </View>

      <View style={styles.formCard}>
        {!sent ? (
          <>
            <Field label="E-MAIL OU CPF" value={identifier} onChangeText={setIdentifier} placeholder="Digite o e-mail ou CPF" icon="person-outline" keyboardType="email-address" error={error} />
            <PrimaryButton onPress={handleRecover} loading={loading} icon="arrow-forward">
              Continuar
            </PrimaryButton>
          </>
        ) : (
          <>
            {notice && <NoticeBanner notice={notice} />}
            <PrimaryButton onPress={() => onNavigate("login")} icon="arrow-forward">
              Voltar para o login
            </PrimaryButton>
          </>
        )}
      </View>
    </ScreenFrame>
  );
}

function GovScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return (
    <ScreenFrame onBack={() => onNavigate("login")}>
      <View style={styles.govHero}>
        <View style={styles.govLargeBadge}><Text style={styles.govLargeBadgeText}>G</Text></View>
        <Text style={styles.eyebrow}>ACESSO INSTITUCIONAL</Text>
        <Text style={styles.title}>Gov.br, por enquanto só no papel.</Text>
        <Text style={styles.subtitle}>Esta opção existe para representar o fluxo futuro. A integração oficial ainda não faz parte desta versão.</Text>
      </View>

      <View style={styles.formCard}>
        <View style={styles.infoRow}>
          <Ionicons name="flask-outline" size={20} color={COLORS.lime} />
          <View style={styles.infoCopy}>
            <Text style={styles.infoTitle}>Modo demonstrativo</Text>
            <Text style={styles.infoText}>Nenhum dado será enviado ao Gov.br e nenhuma autenticação externa será iniciada.</Text>
          </View>
        </View>
        <View style={styles.infoRow}>
          <Ionicons name="lock-closed-outline" size={20} color={COLORS.lime} />
          <View style={styles.infoCopy}>
            <Text style={styles.infoTitle}>Integração prevista</Text>
            <Text style={styles.infoText}>Na versão completa, o acesso deverá respeitar autenticação segura e validação de identidade.</Text>
          </View>
        </View>
        <PrimaryButton onPress={() => onNavigate("login")} icon="arrow-back">
          Voltar para o login
        </PrimaryButton>
      </View>
    </ScreenFrame>
  );
}

export default function HomeScreen() {
  const [screen, setScreen] = useState<Screen>("login");
  const [transitionKey, setTransitionKey] = useState(0);
  const onNavigate = (nextScreen: Screen) => {
    setScreen(nextScreen);
    setTransitionKey((value) => value + 1);
  };

  const currentScreen = useMemo(() => {
    switch (screen) {
      case "signup":
        return <SignupScreen onNavigate={onNavigate} />;
      case "verify":
        return <VerifyScreen onNavigate={onNavigate} />;
      case "forgot":
        return <ForgotScreen onNavigate={onNavigate} />;
      case "gov":
        return <GovScreen onNavigate={onNavigate} />;
      default:
        return <LoginScreen onNavigate={onNavigate} />;
    }
  }, [screen]);

  return (
    <KeyboardAvoidingView key={transitionKey} style={styles.app} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <StatusBar style="light" />
      {currentScreen}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: COLORS.background },
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  page: { flex: 1, width: "100%", maxWidth: 520, alignSelf: "center" },
  topBar: { minHeight: 52, paddingHorizontal: 22, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brand: { flexDirection: "row", alignItems: "center", gap: 11 },
  brandCompact: { gap: 9 },
  brandIcon: { width: 38, height: 38, borderRadius: 14, backgroundColor: "#202A22", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#43552A" },
  wordmark: { color: COLORS.text, fontSize: 18, fontWeight: "800", letterSpacing: -0.5 },
  wordmarkCompact: { fontSize: 16 },
  brandCaption: { color: COLORS.subtle, fontSize: 10, marginTop: 2, letterSpacing: 0.2 },
  livePill: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderColor: COLORS.border, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 7 },
  liveDot: { width: 6, height: 6, borderRadius: 6, backgroundColor: COLORS.lime },
  livePillText: { color: COLORS.muted, fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  backButton: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 8 },
  backButtonText: { color: COLORS.text, fontSize: 13, fontWeight: "700" },
  scrollContent: { paddingHorizontal: 22, paddingBottom: 36 },
  content: { width: "100%", maxWidth: 438, alignSelf: "center" },
  loginIntro: { paddingTop: 32, paddingBottom: 23 },
  innerIntro: { paddingTop: 18, paddingBottom: 22 },
  signalLine: { width: 44, height: 4, borderRadius: 99, backgroundColor: COLORS.border, marginBottom: 20, overflow: "hidden" },
  signalLineFill: { width: 29, height: 4, borderRadius: 99, backgroundColor: COLORS.lime },
  eyebrow: { color: COLORS.lime, fontSize: 11, fontWeight: "800", letterSpacing: 1.4, marginBottom: 12 },
  title: { color: COLORS.text, fontSize: 34, lineHeight: 39, fontWeight: "800", letterSpacing: -1.3, maxWidth: 390 },
  subtitle: { color: COLORS.muted, fontSize: 15, lineHeight: 22, marginTop: 13, maxWidth: 390 },
  formCard: { backgroundColor: COLORS.surface, borderRadius: 26, borderWidth: 1, borderColor: COLORS.border, padding: 20, shadowColor: "#000", shadowOpacity: 0.24, shadowRadius: 20, shadowOffset: { width: 0, height: 10 }, elevation: 8 },
  cardKicker: { color: COLORS.subtle, fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 8 },
  cardTitle: { color: COLORS.text, fontSize: 22, fontWeight: "800", letterSpacing: -0.4 },
  cardDescription: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginTop: 7, marginBottom: 22 },
  fieldWrap: { marginBottom: 15 },
  fieldLabel: { color: COLORS.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1, marginBottom: 8 },
  inputShell: { minHeight: 53, borderWidth: 1, borderColor: COLORS.border, borderRadius: 15, backgroundColor: COLORS.surfaceRaised, flexDirection: "row", alignItems: "center", paddingHorizontal: 15, gap: 11 },
  inputShellError: { borderColor: `${COLORS.coral}AA` },
  input: { flex: 1, color: COLORS.text, fontSize: 14, minHeight: 51, paddingVertical: 0 },
  fieldError: { color: COLORS.coral, fontSize: 11, lineHeight: 15, marginTop: 6 },
  forgotLink: { alignSelf: "flex-end", flexDirection: "row", alignItems: "center", gap: 5, marginTop: -1, marginBottom: 18 },
  linkText: { color: COLORS.lime, fontSize: 13, fontWeight: "800" },
  notice: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderWidth: 1, borderRadius: 13, padding: 12, marginBottom: 15 },
  noticeText: { flex: 1, fontSize: 12, lineHeight: 17, fontWeight: "600" },
  primaryButton: { minHeight: 54, borderRadius: 16, backgroundColor: COLORS.lime, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingHorizontal: 16 },
  primaryButtonPressed: { opacity: 0.58 },
  primaryButtonText: { color: COLORS.background, fontSize: 14, fontWeight: "900", letterSpacing: -0.1 },
  dividerRow: { flexDirection: "row", alignItems: "center", gap: 11, marginVertical: 19 },
  divider: { height: 1, flex: 1, backgroundColor: COLORS.border },
  dividerText: { color: COLORS.subtle, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  govButton: { minHeight: 64, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, backgroundColor: "#171D1B", flexDirection: "row", alignItems: "center", paddingHorizontal: 13, gap: 11 },
  govBadge: { width: 32, height: 32, borderRadius: 10, backgroundColor: "#EBF3F2", alignItems: "center", justifyContent: "center" },
  govBadgeText: { color: "#135C53", fontSize: 18, fontWeight: "900" },
  govCopy: { flex: 1 },
  govTitle: { color: COLORS.text, fontSize: 13, fontWeight: "800" },
  govSubtitle: { color: COLORS.subtle, fontSize: 11, marginTop: 3 },
  createRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, marginTop: 22 },
  mutedText: { color: COLORS.muted, fontSize: 13 },
  privacyNote: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 22, marginBottom: 4 },
  privacyText: { color: COLORS.subtle, fontSize: 11 },
  progressRow: { flexDirection: "row", alignItems: "center", gap: 6, paddingTop: 19, marginBottom: 1 },
  progressDot: { width: 7, height: 7, borderRadius: 7, backgroundColor: COLORS.border },
  progressDotActive: { backgroundColor: COLORS.lime },
  progressLabel: { color: COLORS.subtle, fontSize: 10, fontWeight: "800", letterSpacing: 1.1, marginLeft: 5 },
  helperText: { color: COLORS.subtle, fontSize: 11, lineHeight: 16, marginTop: -2, marginBottom: 17 },
  verificationIcon: { width: 58, height: 58, borderRadius: 19, backgroundColor: "#202A22", borderWidth: 1, borderColor: "#43552A", alignItems: "center", justifyContent: "center", marginBottom: 20 },
  codeInput: { height: 64, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surfaceRaised, borderRadius: 17, color: COLORS.lime, fontSize: 28, fontWeight: "800", letterSpacing: 10, textAlign: "center", paddingLeft: 10, marginBottom: 16 },
  centerLink: { alignItems: "center", paddingTop: 19 },
  demoHint: { color: COLORS.subtle, fontSize: 11, textAlign: "center", marginTop: 17 },
  govHero: { alignItems: "flex-start", paddingTop: 31, paddingBottom: 24 },
  govLargeBadge: { width: 72, height: 72, borderRadius: 24, backgroundColor: "#EBF3F2", alignItems: "center", justifyContent: "center", marginBottom: 24 },
  govLargeBadgeText: { color: "#135C53", fontSize: 38, fontWeight: "900" },
  infoRow: { flexDirection: "row", gap: 13, paddingBottom: 20, marginBottom: 18, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  infoCopy: { flex: 1 },
  infoTitle: { color: COLORS.text, fontSize: 14, fontWeight: "800", marginBottom: 5 },
  infoText: { color: COLORS.muted, fontSize: 12, lineHeight: 18 },
});
