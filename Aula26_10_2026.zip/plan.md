# Plano — Guardião: primeiro fluxo de entrada

## Escopo
Implementar a primeira etapa do aplicativo mobile em React Native com Expo: autenticação local e demonstrativa para apresentação em sala. O fluxo cobre login, criação de conta, validação por código, recuperação de palavra-passe e uma entrada didática para o Gov.br. Não haverá backend real, OAuth real, armazenamento de credenciais, feed de alertas, mapa, GPS, câmera, CRUD ou WebView nesta etapa.

## Abordagem de implementação
- Reutilizar o starter Expo Router/React Native/TypeScript existente.
- Manter uma única rota de entrada em `app/(tabs)/index.tsx`, com estado local para alternar entre ecrãs do fluxo sem introduzir dependências novas.
- Usar componentes nativos (`View`, `Text`, `TextInput`, `Pressable`, `ScrollView`) e estilos definidos localmente com `StyleSheet` para assegurar comportamento consistente no Expo Web e em dispositivos.
- Simular validações, carregamento, sucesso e erro no cliente. O código de validação demonstrativo será `246810`.
- Simplificar a navegação do starter para esconder a tab bar e apresentar o fluxo como uma experiência de entrada de ecrã inteiro.
- Preservar os identificadores Expo e os listeners fixos 8081/3000 do starter.

## Design

### Design Movement
**Dark civic-tech premium**: a linguagem escura e neon da referência é reinterpretada como uma interface de proteção digital, com calor humano nos textos e precisão nos estados.

### Core Principles
1. **Proteção em primeiro plano** — hierarquia clara, poucos elementos por ecrã e cópias que reduzem ansiedade.
2. **Contraste responsável** — fundo quase preto, superfícies grafite e verde-lima apenas para ações e estados importantes.
3. **Confiança sem exposição** — não apresentar dados sensíveis; o Gov.br é explicitamente marcado como demonstração.
4. **Uma mão, um passo** — botões grandes, campos espaçosos e progressão linear com retorno evidente.

### Color Philosophy
O preto azulado `#0B0E0D` cria concentração e segurança. O grafite `#151A18` separa superfícies sem parecer um formulário genérico. O verde-lima `#C8FF3D` é a assinatura do Guardião: energia, atenção e esperança; será reservado a CTAs, indicadores e detalhes de marca. Tons âmbar e coral aparecem apenas para avisos e erros, nunca como decoração.

### Layout Paradigm
Composição vertical de foco: marca compacta no topo, mensagem editorial curta, cartão de formulário com borda fina e uma faixa de confiança no rodapé. O conteúdo usa largura confortável em mobile e fica limitado a 460px em ecrãs largos, evitando um layout desktopizado.

### Signature Elements
- Marca formada por um escudo circular interrompido por um ponto-luz, simbolizando proteção e sinalização.
- Indicador de progresso em três pontos nas telas de criação/validação/recuperação.
- Cartões de ação com raio grande e linhas de contorno verde-lima de baixa opacidade.

### Interaction Philosophy
Cada ação informa o próximo passo. Estados inválidos aparecem junto ao campo; estados de sucesso usam confirmação curta e permitem continuar. O Gov.br abre um ecrã informativo sem simular autenticação externa.

### Animation
Usar apenas transições leves e nativas quando já disponíveis no starter; não adicionar animações decorativas que atrasem o acesso. O feedback de carregamento será textual e temporário para ficar claro na demonstração.

### Typography System
Usar `System`/San Francisco no iOS e Roboto no Android via família nativa. Títulos em peso 800, corpo em 400–500, labels em 700 e microcopy em 12–14px. O contraste entre título grande e labels compactos aproxima a referência premium sem comprometer a leitura.

### Brand Essence
**Guardião acompanha pessoas comuns a agir com segurança quando cada minuto importa.** Personalidade: atento, acolhedor, responsável.

### Brand Voice
Direta, calma e humana. Exemplos: “Entre para ajudar com responsabilidade.” e “A sua conta está protegida para que a informação certa chegue a quem precisa.”

### Wordmark & Logo
Wordmark “guardião” em minúsculas, acompanhado de um escudo aberto com ponto central. No protótipo, o escudo é desenhado com formas nativas e ícone linear para manter a interface leve.

### Signature Brand Color
Verde-lima `#C8FF3D`.

## Estrutura de projeto
- `app/(tabs)/index.tsx`: máquina de estados do fluxo e componentes de tela do protótipo.
- `app/(tabs)/_layout.tsx`: configura a rota inicial como experiência sem tab bar.
- `app/_layout.tsx`: providers e inicialização do runtime Expo, preservados.
- `plan.md`: decisões de implementação e design.
- `TODO.md`: resultados e critérios da entrega atual.
