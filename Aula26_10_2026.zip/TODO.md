# TODO — Guardião: primeiro fluxo de entrada

## Fluxo de login navegável
- [x] A aplicação abre num ecrã de login mobile com fundo quase preto, linguagem visual escura e moderna, cartões arredondados, alto contraste, verde-lima neon, ícones lineares e copy acolhedora.
- [x] O ecrã de login contém campos de e-mail ou CPF e palavra-passe, ação principal de entrada, ligação para criar conta, ligação para esquecer a palavra-passe e opção didática do Gov.br.
- [x] A entrada valida os campos localmente e apresenta estados de erro, carregamento simulado e sucesso demonstrativo sem enviar credenciais para um backend real.

## Criação e validação de conta
- [x] O fluxo de criação de conta permite informar nome, e-mail, palavra-passe e confirmação da palavra-passe, com validação local de campos vazios, formato de e-mail e correspondência das palavras-passe.
- [x] Após o formulário válido, a aplicação apresenta uma mensagem de conta criada e navega para um ecrã de validação.
- [x] O ecrã de validação permite introduzir um código de demonstração e diferencia código válido de inválido, com ação para reenviar e voltar.

## Recuperação de palavra-passe
- [x] O fluxo de recuperação permite informar e-mail ou CPF, apresenta erro para campo vazio e confirmação informativa local após envio.
- [x] A confirmação permite regressar ao login sem alegar envio real de e-mail ou alteração real de credenciais.

## Gov.br didático e navegação
- [x] A opção Gov.br leva a um ecrã informativo/placeholder que explica que a integração ainda não está implementada; não simula autenticação real.
- [x] Todos os ecrãs têm ações claras de voltar, avançar e regressar ao login, com progressão linear e responsiva em portrait.
- [x] O projeto preserva a base Expo Router/React Native/TypeScript e os identificadores do starter, sem introduzir feed, mapa, GPS, câmera, CRUD, WebView ou backend nesta fase.
