# Guardião — Primeiro fluxo de autenticação

Projeto mobile criado com React Native, Expo, Expo Router e TypeScript.

## O que está implementado

A primeira etapa contém login, criação de conta, validação por código, recuperação de palavra-passe e uma tela informativa do Gov.br. Tudo funciona como protótipo local, sem backend real e sem autenticação externa.

O código de validação demonstrativo é:

```text
246810
```

## Como executar

É necessário ter Node.js e pnpm instalados.

```bash
pnpm install
pnpm dev
```

Depois, abra o endereço indicado pelo Expo. Para testar no navegador, use o preview Expo Web em `http://localhost:8081`.

Também é possível abrir no Expo Go usando o QR Code apresentado pelo Expo, desde que o projeto seja executado num ambiente acessível pelo telemóvel.

## Estrutura principal

- `app/(tabs)/index.tsx`: fluxo completo de autenticação e navegação local.
- `app/(tabs)/_layout.tsx`: configuração da rota principal sem barra de tabs.
- `app/_layout.tsx`: configuração geral do Expo Router e providers.
- `assets/images/`: ícones, splash screen e favicon do Guardião.
- `plan.md`: plano de implementação e decisões visuais.
- `TODO.md`: critérios entregues nesta etapa.

## Observação sobre o Gov.br

A opção Gov.br é somente didática nesta versão. Ela abre uma tela explicativa e não envia dados nem realiza autenticação real.
